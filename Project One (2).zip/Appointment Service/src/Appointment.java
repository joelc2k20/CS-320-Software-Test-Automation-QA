//Appointment.java

import java.util.Date;

public class Appointment {
	private String id;
	private Date appointmentDate;
	private String description;

	private Appointment(String id, Date appointmentDate, String description) {
		this.id = id;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}

	public static Appointment bookAppointment(String id, Date appointmentDate, String description) {
		// we will book appointment only on valid data
		// you can use below code to create an object of Appointment
		// Appointment appointment = Appointment.bookAppointment(id, appointmentDate,
		// description);
		if (id.length() > 10 || id == null) {
			System.out.println("Invalid ID");
			return null;
		}

		if (appointmentDate == null || appointmentDate.before(new Date())) {
			System.out.println("Invalid Appointment Date");
			return null;
		}

		if (description.length() > 50 || description == null) {
			System.out.println("Invalid Description");
			return null;
		}

		return new Appointment(id, appointmentDate, description);
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return id;
	}

}
