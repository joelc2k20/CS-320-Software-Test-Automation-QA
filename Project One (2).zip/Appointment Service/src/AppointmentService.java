//AppointmentService.java
import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	ArrayList<Appointment> data;

	public AppointmentService() {
		data = new ArrayList<Appointment>();
	}

	public boolean addAppointment(String id, Date appointmentDate, String description) {
		Appointment temp = Appointment.bookAppointment(id, appointmentDate, description);

		if (temp != null) {
			if (!data.contains(temp)) {
				data.add(temp);
				return true;
			}
		}
		return false;
	}

	public boolean deleteAppointment(String id) {
		for (Appointment temp : data) {
			if (temp.getId().equals(id)) {
				data.remove(temp);
				return true;
			}
		}
		return false;
	}
	
}